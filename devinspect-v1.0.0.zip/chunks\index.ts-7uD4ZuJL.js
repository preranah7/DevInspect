(function(){let h="light";function O(){try{h=localStorage.getItem("ff-theme")||"light",document.documentElement.setAttribute("data-ff-theme",h)}catch{h="light",document.documentElement.setAttribute("data-ff-theme","light")}}function D(){try{h=h==="light"?"dark":"light",document.documentElement.setAttribute("data-ff-theme",h);try{localStorage.setItem("ff-theme",h)}catch{}A()}catch{}}function A(){try{const t=document.querySelector(".ff-sun-icon"),e=document.querySelector(".ff-moon-icon");t&&e&&(h==="dark"?(t.style.display="block",e.style.display="none"):(t.style.display="none",e.style.display="block"))}catch{}}function W(t,e){let s=null;return function(...n){try{const o=()=>{s=null,t(...n)};s!==null&&clearTimeout(s),s=setTimeout(o,e)}catch{}}}function q(t,e){try{let s=e.get(t);return s||(s=window.getComputedStyle(t),e.set(t,s)),s}catch{return window.getComputedStyle(t)}}function U(t){try{if(t.id)return`#${CSS.escape(t.id)}`;if(t.className&&typeof t.className=="string"){const e=t.className.trim().split(/\s+/).filter(s=>s);if(e.length>0){const s=e.map(i=>CSS.escape(i)).join(".");return`${t.tagName.toLowerCase()}.${s}`}}return V(t)}catch{return t.tagName?.toLowerCase()||"unknown"}}function G(t){try{if(t.id)return`//*[@id="${t.id}"]`;const e=[];let s=t;for(;s&&s.nodeType===Node.ELEMENT_NODE;){let i=0,n=s.previousSibling;for(;n;)n.nodeType===Node.ELEMENT_NODE&&n.nodeName===s.nodeName&&i++,n=n.previousSibling;const o=s.nodeName.toLowerCase(),a=i>0?`[${i+1}]`:"";e.unshift(`${o}${a}`),s=s.parentElement}return e.length>0?"/"+e.join("/"):"/html"}catch{return`//${t.tagName?.toLowerCase()||"unknown"}`}}function V(t){try{const e=t.parentElement;if(!e)return t.tagName.toLowerCase();const i=Array.from(e.children).indexOf(t);if(i===-1)return t.tagName.toLowerCase();const n=e.tagName.toLowerCase(),o=t.tagName.toLowerCase();return`${n} > ${o}:nth-child(${i+1})`}catch{return t.tagName?.toLowerCase()||"unknown"}}function X(t){try{return{css:U(t),xpath:G(t)}}catch{return{css:t.tagName?.toLowerCase()||"unknown",xpath:`//${t.tagName?.toLowerCase()||"unknown"}`}}}function J(t){const e=[];try{const s=window.getComputedStyle(t),i=t.getBoundingClientRect();j(t,i,e),_(t,e),K(t,e),Q(s,e),Y(s,e)}catch{}return e}function j(t,e,s){try{const i=e.width,n=e.height,o=["A","BUTTON","INPUT"].includes(t.tagName);i>=44&&n>=44||!o||s.push({type:"touch-target",severity:"error",message:`Touch target too small: ${Math.round(i)}×${Math.round(n)}px (needs 44×44px)`})}catch{}}function _(t,e){try{t.tagName==="IMG"&&!t.hasAttribute("alt")&&e.push({type:"aria",severity:"error",message:"Image missing alt attribute"})}catch{}}function K(t,e){try{["A","BUTTON"].includes(t.tagName)&&!(t.hasAttribute("aria-label")||t.hasAttribute("aria-labelledby"))&&!t.textContent?.trim()&&e.push({type:"aria",severity:"error",message:"Interactive element missing accessible label"})}catch{}}function Q(t,e){try{const s=parseFloat(t.fontSize);!isNaN(s)&&s<12&&e.push({type:"font-size",severity:"warning",message:`Font size too small: ${s}px (minimum 12px recommended)`})}catch{}}function Y(t,e){try{const s=t.color,i=t.backgroundColor;if(s&&i){const n=Z(s,i);n<4.5&&e.push({type:"contrast",severity:"warning",message:`Low contrast ratio: ${n.toFixed(2)}:1 (needs 4.5:1)`})}}catch{}}function Z(t,e){try{const s=T(t),i=T(e);if(!s||!i)return 21;const n=I(s),o=I(i),a=Math.max(n,o),f=Math.min(n,o);return(a+.05)/(f+.05)}catch{return 21}}function T(t){try{const e=t.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);return e?{r:parseInt(e[1]),g:parseInt(e[2]),b:parseInt(e[3])}:null}catch{return null}}function I(t){try{const e=t.r/255,s=t.g/255,i=t.b/255,n=e<=.03928?e/12.92:Math.pow((e+.055)/1.055,2.4),o=s<=.03928?s/12.92:Math.pow((s+.055)/1.055,2.4),a=i<=.03928?i/12.92:Math.pow((i+.055)/1.055,2.4);return .2126*n+.7152*o+.0722*a}catch{return 0}}function tt(t){try{const e=window.getComputedStyle(t),s=e.display;return s==="flex"||s==="inline-flex"?{display:"flexbox",flexDirection:e.flexDirection||"row",justifyContent:e.justifyContent||"normal",alignItems:e.alignItems||"normal",gap:e.gap||"0px"}:s==="grid"||s==="inline-grid"?{display:"grid",gridTemplateColumns:e.gridTemplateColumns||"none",gridTemplateRows:e.gridTemplateRows||"none",gap:e.gap||"0px"}:null}catch{return null}}function et(t){try{const e=window.innerWidth,s=N(e),i=st(),n=window.getComputedStyle(t),o=it(n),a=nt(n);return{breakpoint:s.name,breakpointColor:s.color,breakpointRange:s.range,width:e,mediaQueries:i,fluidSizing:o,viewportUnits:a}}catch{return ot()}}function N(t){return t<768?{name:"Mobile",color:"#ef4444",range:"<768px"}:t<1024?{name:"Tablet",color:"#f59e0b",range:"768-1024px"}:{name:"Desktop",color:"#10b981",range:">1024px"}}function st(){try{const t=Array.from(document.styleSheets).filter(e=>{try{return e.cssRules!==null}catch{return!1}});for(const e of t)try{for(const s of Array.from(e.cssRules))if(s.type===CSSRule.MEDIA_RULE)return!0}catch{}return!1}catch{return!1}}function it(t){try{return["width","height","fontSize","padding","margin"].some(s=>{try{const i=t.getPropertyValue(s);return i?i.includes("calc")||i.includes("clamp")||i.includes("min(")||i.includes("max(")||i.includes("vw")||i.includes("vh")||i.includes("vmin")||i.includes("vmax")||i.includes("%"):!1}catch{return!1}})}catch{return!1}}function nt(t){try{return["width","height","fontSize"].some(s=>{try{const i=t.getPropertyValue(s);return i?i.includes("vw")||i.includes("vh")||i.includes("vmin")||i.includes("vmax"):!1}catch{return!1}})}catch{return!1}}function ot(){const t=window.innerWidth||1024,e=N(t);return{breakpoint:e.name,breakpointColor:e.color,breakpointRange:e.range,width:t,mediaQueries:!1,fluidSizing:!1,viewportUnits:!1}}let S=null,E=0;const at=5e3;let k=!1;const r={lcp:null,cls:0,fid:null,inp:null,ttfb:null};function rt(){if(!k&&"PerformanceObserver"in window){k=!0;try{new PerformanceObserver(e=>{try{const s=e.getEntries(),i=s[s.length-1];i&&(r.lcp=i.renderTime||i.loadTime||0)}catch{}}).observe({type:"largest-contentful-paint",buffered:!0})}catch{}try{new PerformanceObserver(e=>{try{for(const s of e.getEntries()){const i=s;i.hadRecentInput||(r.cls+=i.value)}}catch{}}).observe({type:"layout-shift",buffered:!0})}catch{}try{new PerformanceObserver(e=>{try{const s=e.getEntries()[0];s&&(r.fid=s.processingStart-s.startTime)}catch{}}).observe({type:"first-input",buffered:!0})}catch{}try{new PerformanceObserver(e=>{try{e.getEntries().forEach(i=>{i.duration&&i.duration>40&&(r.inp===null||i.duration>r.inp)&&(r.inp=i.duration)})}catch{}}).observe({type:"event",buffered:!0})}catch{}try{const t=performance.getEntriesByType("navigation")[0];t&&(r.ttfb=t.responseStart-t.requestStart)}catch{}}}function lt(){try{const t=Date.now();if(S&&t-E<at)return S;const e=ct();return S=e,E=t,e}catch{return L()}}function L(){return{lcp:null,fid:null,cls:0,ttfb:null,inp:null,totalNodes:0,totalImages:0,totalScripts:0,totalStylesheets:0,warnings:[]}}function ct(){if(!window.performance)return L();try{const t=document.querySelectorAll("*").length,e=performance.getEntriesByType("resource"),s=e.filter(l=>l.initiatorType==="img"),i=e.filter(l=>l.initiatorType==="script"),n=e.filter(l=>l.initiatorType==="link"||l.initiatorType==="css"),o=[],a=r.lcp!==null&&r.lcp>2500,f=r.cls!==null&&r.cls>.1,d=r.ttfb!==null&&r.ttfb>800,c=r.fid!==null&&r.fid>100,u=r.inp!==null&&r.inp>200;if(a){const l=s.filter(v=>(v.transferSize||0)>2e5);if(l.length>0){const v=(l.reduce((x,$)=>x+($.transferSize||0),0)/l.length/1024).toFixed(0);o.push({title:`${l.length} large images detected (avg ${v}KB)`,solution:"Compress images, convert to WebP/AVIF, use responsive images with srcset, implement lazy loading",severity:"high"})}}if(f&&o.push({title:`Poor layout stability (CLS: ${r.cls.toFixed(3)})`,solution:"Set explicit width/height on images and ads. Reserve space for dynamic content. Avoid inserting content above existing content",severity:"high"}),d){const l=r.ttfb;o.push({title:`Slow server response time (${l.toFixed(0)}ms)`,solution:"Optimize backend queries, use CDN, implement server-side caching, upgrade hosting plan",severity:"medium"})}if(c||u){const l=c?`FID: ${r.fid}ms`:`INP: ${r.inp}ms`;o.push({title:`Slow interactivity detected (${l})`,solution:"Reduce JavaScript execution time, break up long tasks, use web workers for heavy computation",severity:"high"})}if(a){const l=i.filter(v=>(v.transferSize||0)>5e5);if(l.length>0){const v=(l.reduce((x,$)=>x+($.transferSize||0),0)/1024).toFixed(0);o.push({title:`Heavy JavaScript detected (${v}KB across ${l.length} files)`,solution:"Code-split bundles, defer non-critical JS, remove unused dependencies, enable compression",severity:"medium"})}}const g=document.querySelectorAll("img:not([alt])").length;return g>0&&o.push({title:`${g} images missing alt attributes`,solution:"Add descriptive alt text to all images for accessibility and SEO",severity:"low"}),{lcp:r.lcp,fid:r.fid,cls:r.cls,ttfb:r.ttfb,inp:r.inp,totalNodes:t,totalImages:s.length,totalScripts:i.length,totalStylesheets:n.length,warnings:o}}catch{return L()}}let m=!1,p=null,M=new WeakMap;function B(t){m=t}function P(t){p=t}function ft(){M=new WeakMap}function dt(t){try{const e=document.getElementById("ff-panel");e&&e.remove(),ft();const s=pt(),i=document.createElement("div");i.className="ff-content-wrapper";const n=ut(t);i.innerHTML=vt(t,n),s.appendChild(i),document.body.appendChild(s),Nt(s),Mt(),Lt(s,n.selectors),A()}catch{}}function pt(){const t=document.createElement("div");t.id="ff-panel",t.className="ff-panel";try{localStorage.getItem("ff-panel-collapsed")==="true"&&t.classList.add("ff-panel-collapsed");const s=localStorage.getItem("ff-panel-position");if(s){const i=JSON.parse(s);t.style.left=i.left+"px",t.style.top=i.top+"px",t.style.right="auto",t.style.bottom="auto"}else t.style.top="20px",t.style.right="20px"}catch{t.style.top="20px",t.style.right="20px"}return t}function ut(t){const e=t.getBoundingClientRect(),s=q(t,M),i=X(t),n=lt(),o=et(t),a=tt(t),f=J(t),d=kt(t),c=It(t),u=Et(t),g=t.className&&typeof t.className=="string"?`.${t.className.trim().split(/\s+/).join(".")}`:"";let l={};try{l=JSON.parse(localStorage.getItem("ff-collapsed-sections")||"{}")}catch{l={}}return{rect:e,styles:s,selectors:i,performance:n,responsive:o,layout:a,a11yIssues:f,ariaData:d,boxModel:c,typography:u,classInfo:g,collapsedSections:l}}function vt(t,e){const s=localStorage.getItem("ff-panel-collapsed")==="true",i=xt(e.layout,e.collapsedSections),n=yt(e.performance.warnings),o=$t(e.a11yIssues),a=Tt(e.selectors.css);return`
    ${gt(s)}
    ${ht(t,e)}
    ${mt(e)}
    ${n}
    ${bt(e.selectors,a,e.collapsedSections)}
    ${i}
    ${St(e.ariaData,o,e.collapsedSections)}
    ${wt(e.boxModel,e.collapsedSections)}
    ${Ct(e.typography,e.collapsedSections)}
  `}function gt(t){return`
    <div class="ff-panel-header" id="ff-panel-header">
      <h3 class="ff-panel-title">
        <span class="ff-drag-indicator">⋮⋮</span> Element Inspector
      </h3>
      <div style="display: flex; align-items: center; gap: 8px;">
        <button id="ff-collapse-all" class="ff-collapse-all-btn" title="Collapse panel">
          <span class="ff-collapse-all-icon">${t?"▶":"▼"}</span>
        </button>
        <button id="ff-theme-toggle" class="ff-theme-toggle" title="Toggle theme">
          <img class="ff-sun-icon" src="${chrome.runtime.getURL("icons/sun.svg")}" width="18" height="18" alt="Light theme">
          <img class="ff-moon-icon" src="${chrome.runtime.getURL("icons/moon.svg")}" width="18" height="18" alt="Dark theme">
        </button>
        <button id="closePanel" class="ff-close-btn" title="Close (Esc)">×</button>
      </div>
    </div>
  `}function ht(t,e){return`
    <div class="ff-compact-header">
      <div class="ff-compact-tag">
        <span class="ff-compact-tag-name">&lt;${t.tagName.toLowerCase()}&gt;</span>
        <span class="ff-compact-tag-class">${e.classInfo}</span>
      </div>
      
      <div class="ff-compact-grid">
        <div class="ff-compact-item">
          <span class="ff-compact-label">Size</span>
          <span class="ff-compact-value">${Math.round(e.rect.width)} × ${Math.round(e.rect.height)}px</span>
        </div>
        
        <div class="ff-compact-item">
          <span class="ff-compact-label">Position</span>
          <span class="ff-compact-value">${Math.round(e.rect.left)}, ${Math.round(e.rect.top)}</span>
        </div>
        
        <div class="ff-compact-item">
          <span class="ff-compact-label">Display</span>
          <span class="ff-compact-value">${e.styles.display}</span>
        </div>
        
        <div class="ff-compact-item">
          <span class="ff-compact-label">Position Type</span>
          <span class="ff-compact-value">${e.styles.position}</span>
        </div>
      </div>
    </div>
  `}function mt(t,e){const{performance:s,responsive:i,collapsedSections:n}=t;return`
    <div class="ff-performance-card ff-collapsible-section ${n.performance?"collapsed":""}" data-section="performance">
      <h4 class="ff-section-title ff-collapsible-header">
        <span class="ff-collapse-icon">${n.performance?"▶":"▼"}</span>
        Web Vitals & Performance
      </h4>
      <div class="ff-collapsible-content">
        <div class="ff-vitals-grid">
          <div class="ff-vital-item ${w(s.lcp,2500,4e3)}">
            <div class="ff-vital-label">LCP</div>
            <div class="ff-vital-value">${s.lcp?(s.lcp/1e3).toFixed(2)+"s":"N/A"}</div>
            <div class="ff-vital-status">${s.lcp?s.lcp<2500?"Good":s.lcp<4e3?"Needs Work":"Poor":"-"}</div>
          </div>
          
          <div class="ff-vital-item ${w(s.cls,.1,.25,!0)}">
            <div class="ff-vital-label">CLS</div>
            <div class="ff-vital-value">${s.cls!==null?s.cls.toFixed(3):"N/A"}</div>
            <div class="ff-vital-status">${s.cls!==null?s.cls<.1?"Good":s.cls<.25?"Needs Work":"Poor":"-"}</div>
          </div>
          
          <div class="ff-vital-item ${w(s.ttfb,800,1800)}">
            <div class="ff-vital-label">TTFB</div>
            <div class="ff-vital-value">${s.ttfb?s.ttfb.toFixed(0)+"ms":"N/A"}</div>
            <div class="ff-vital-status">${s.ttfb?s.ttfb<800?"Good":s.ttfb<1800?"Needs Work":"Poor":"-"}</div>
          </div>
          
          <div class="ff-vital-item ff-vital-neutral">
            <div class="ff-vital-label">DOM Size</div>
            <div class="ff-vital-value">${s.totalNodes||0}</div>
            <div class="ff-vital-status">${(s.totalNodes||0)<1500?"Good":"Large"}</div>
          </div>
        </div>

        <div class="ff-breakpoint-info">
          <span class="ff-breakpoint-badge ff-breakpoint-${i.breakpoint.toLowerCase()}">${i.breakpoint}: ${i.width}px</span>
          <span class="ff-breakpoint-detail ${i.mediaQueries?"ff-feature-active":"ff-feature-inactive"}">${i.mediaQueries?"✓ Responsive":"✗ Not Responsive"}</span>
          <span class="ff-breakpoint-detail ${i.fluidSizing?"ff-feature-active":"ff-feature-inactive"}">${i.fluidSizing?"✓ Fluid":"✗ Fixed"}</span>
        </div>
      </div>
    </div>
  `}function yt(t){return t.length>0?`
      <div class="ff-actionable-warnings">
        ${t.map(e=>`
          <div class="ff-warning-item ff-warning-${e.severity}">
            <div class="ff-warning-header">
              <span class="ff-warning-title">${e.title}</span>
            </div>
            <div class="ff-warning-solution">${e.solution}</div>
          </div>
        `).join("")}
      </div>
    `:`
      <div class="ff-success-box" style="margin: 0 24px 16px 24px;">
        <div class="ff-success-text">No performance issues detected</div>
      </div>
    `}function bt(t,e,s){return`
    <div class="ff-selector-card ff-collapsible-section ${s.selectors?"collapsed":""}" data-section="selectors">
      <h4 class="ff-section-title ff-collapsible-header">
        <span class="ff-collapse-icon">${s.selectors?"▶":"▼"}</span>
        CSS Selector Extractor
      </h4>
      <div class="ff-collapsible-content">
        <div style="margin-bottom:10px;">
          <div class="ff-selector-label">CSS SELECTOR</div>
          <div class="ff-selector-row">
            <div id="cssSelectorText" class="ff-selector-text ff-selector-css">${t.css}</div>
            <button class="ff-copy-btn ff-copy-btn-css copy-css-btn">Copy</button>
          </div>
        </div>

        <div style="margin-bottom:10px;">
          <div class="ff-selector-label">XPATH</div>
          <div class="ff-selector-row">
            <div id="xpathText" class="ff-selector-text ff-selector-xpath">${t.xpath.length>60?t.xpath.substring(0,60)+"...":t.xpath}</div>
            <button class="ff-copy-btn ff-copy-btn-xpath copy-xpath-btn">Copy</button>
          </div>
        </div>

        <div class="ff-specificity-box">
          <strong>Specificity:</strong> ${e.score} <span style="color:var(--ff-text-tertiary);">(${e.ids} IDs, ${e.classes} classes, ${e.elements} elements)</span>
        </div>
      </div>
    </div>
  `}function xt(t,e){if(!t)return"";let s="";return t.display==="flexbox"&&(s+=`
      <div class="ff-layout-card ff-flex-container">
        <div class="ff-layout-title ff-flex-title">Flex Container</div>
        <div class="ff-layout-grid">
          <div><span class="ff-layout-label">Direction:</span><br><span class="ff-layout-value">${t.flexDirection||"row"}</span></div>
          <div><span class="ff-layout-label">Justify:</span><br><span class="ff-layout-value">${t.justifyContent||"normal"}</span></div>
          <div><span class="ff-layout-label">Align:</span><br><span class="ff-layout-value">${t.alignItems||"normal"}</span></div>
          <div><span class="ff-layout-label">Gap:</span><br><span class="ff-layout-value">${t.gap||"0px"}</span></div>
        </div>
      </div>
    `),t.display==="grid"&&(s+=`
      <div class="ff-layout-card ff-grid-container">
        <div class="ff-layout-title ff-grid-title">Grid Container</div>
        <div style="font-size:11px;">
          <div style="margin-bottom:6px;">
            <span class="ff-layout-label">Columns:</span>
            <span class="ff-layout-value">${t.gridTemplateColumns||"none"}</span>
          </div>
          <div>
            <span class="ff-layout-label">Rows:</span>
            <span class="ff-layout-value">${t.gridTemplateRows||"none"}</span>
          </div>
        </div>
      </div>
    `),s?`
    <div class="ff-section-divider ff-collapsible-section ${e.layout?"collapsed":""}" data-section="layout">
      <h4 class="ff-section-title ff-collapsible-header">
        <span class="ff-collapse-icon">${e.layout?"▶":"▼"}</span>
        Layout Detection
      </h4>
      <div class="ff-collapsible-content">
        ${s}
      </div>
    </div>
  `:""}function $t(t){return t.length>0?`
      <div class="ff-warning-box">
        <div class="ff-warning-title">Accessibility Issues:</div>
        ${t.map(e=>`
          <div style="font-size:11px; margin-bottom:4px; color:var(--ff-text-secondary);">${e.message}</div>
        `).join("")}
      </div>
    `:`
      <div class="ff-success-box">
        <div class="ff-success-text">No accessibility issues detected</div>
      </div>
    `}function St(t,e,s){return`
    <div class="ff-section-divider ff-collapsible-section ${s.accessibility?"collapsed":""}" data-section="accessibility">
      <h4 class="ff-section-title ff-collapsible-header">
        <span class="ff-collapse-icon">${s.accessibility?"▶":"▼"}</span>
        Accessibility
      </h4>
      <div class="ff-collapsible-content">
        <div class="ff-a11y-grid">
          <div>
            <div class="ff-a11y-label">ARIA Role</div>
            <div class="ff-badge">${t.role}</div>
          </div>
          <div>
            <div class="ff-a11y-label">Tab Index</div>
            <div class="ff-badge">${t.tabIndex}</div>
          </div>
          <div style="grid-column: 1 / -1;">
            <div class="ff-a11y-label">ARIA Label</div>
            <div class="ff-badge" style="width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${t.ariaLabel}</div>
          </div>
          <div>
            <div class="ff-a11y-label">ARIA Hidden</div>
            <div class="ff-badge ${t.ariaHidden==="true"?"ff-a11y-warning":""}">${t.ariaHidden}</div>
          </div>
          <div>
            <div class="ff-a11y-label">ARIA Live</div>
            <div class="ff-badge">${t.ariaLive}</div>
          </div>
        </div>
        
        ${e}
      </div>
    </div>
  `}function wt(t,e){return`
    <div class="ff-section-divider ff-collapsible-section ${e.boxModel?"collapsed":""}" data-section="boxModel">
      <h4 class="ff-section-title ff-collapsible-header">
        <span class="ff-collapse-icon">${e.boxModel?"▶":"▼"}</span>
        Box Model
      </h4>
      <div class="ff-collapsible-content">
        <div class="ff-box-model">
          <div class="ff-box-label">margin</div>
          <div class="ff-box-margin-top">${t.margin.top}px</div>
          <div class="ff-box-grid">
            <div class="ff-box-margin-left">${t.margin.left}px</div>
            <div class="ff-box-border">border</div>
            <div class="ff-box-margin-right">${t.margin.right}px</div>
          </div>
          <div class="ff-box-margin-bottom">${t.margin.bottom}px</div>
        </div>

        <div class="ff-box-details-grid">
          <div>
            <div class="ff-box-detail-label">Padding</div>
            <div class="ff-box-detail-value">${t.padding.top} / ${t.padding.right} / ${t.padding.bottom} / ${t.padding.left}</div>
          </div>
          <div>
            <div class="ff-box-detail-label">Border Width</div>
            <div class="ff-box-detail-value">${t.border.top} / ${t.border.right} / ${t.border.bottom} / ${t.border.left}</div>
          </div>
        </div>
      </div>
    </div>
  `}function Ct(t,e){return`
    <div class="ff-section-divider ff-collapsible-section ${e.typography?"collapsed":""}" data-section="typography" style="padding-bottom: 24px;">
      <h4 class="ff-section-title ff-collapsible-header">
        <span class="ff-collapse-icon">${e.typography?"▶":"▼"}</span>
        Typography
      </h4>
      <div class="ff-collapsible-content">
        <div class="ff-typo-grid">
          <div>
            <div class="ff-typo-label">Font Size</div>
            <div class="ff-typo-value">${t.fontSize}</div>
          </div>
          <div>
            <div class="ff-typo-label">Font Weight</div>
            <div class="ff-typo-value">${t.fontWeight}</div>
          </div>
          <div>
            <div class="ff-typo-label">Line Height</div>
            <div class="ff-typo-value">${t.lineHeight}</div>
          </div>
          <div>
            <div class="ff-typo-label">Text Align</div>
            <div class="ff-typo-value">${t.textAlign}</div>
          </div>
          <div class="ff-typo-full">
            <div class="ff-typo-label">Font Family</div>
            <div class="ff-typo-value ff-typo-value-small">${t.fontFamily}</div>
          </div>
          <div>
            <div class="ff-typo-label">Text Color</div>
            <div class="ff-color-value ff-typo-value">
              <span class="ff-color-swatch" style="background-color: ${t.color};"></span>
              <span>${At(t.color)}</span>
            </div>
          </div>
          <div>
            <div class="ff-typo-label">Letter Spacing</div>
            <div class="ff-typo-value">${t.letterSpacing}</div>
          </div>
        </div>
      </div>
    </div>
  `}function Lt(t,e){try{const s=document.getElementById("closePanel");s&&s.addEventListener("click",()=>t.remove());const i=document.getElementById("ff-theme-toggle");i&&i.addEventListener("click",D);const n=document.getElementById("ff-collapse-all");n&&n.addEventListener("click",()=>Bt(t)),t.querySelectorAll(".copy-css-btn").forEach(d=>{d.addEventListener("click",()=>y(e.css,"CSS Selector copied!"))}),t.querySelectorAll(".copy-xpath-btn").forEach(d=>{d.addEventListener("click",()=>y(e.xpath,"XPath copied!"))});const o=document.getElementById("cssSelectorText");o&&o.addEventListener("click",()=>y(e.css,"CSS Selector copied!"));const a=document.getElementById("xpathText");a&&a.addEventListener("click",()=>y(e.xpath,"XPath copied!"));const f=d=>{d.key==="Escape"&&(t.remove(),document.removeEventListener("keydown",f))};document.addEventListener("keydown",f)}catch{}}function y(t,e){try{navigator.clipboard.writeText(t).then(()=>{C(e)}).catch(()=>{C("Copy failed")})}catch{C("Copy failed")}}function w(t,e,s,i=!1){return t==null?"ff-vital-neutral":t<e?"ff-vital-good":t<s?"ff-vital-needs-work":"ff-vital-poor"}function Tt(t){const e=(t.match(/#[a-zA-Z][a-zA-Z0-9_-]*/g)||[]).length,s=(t.match(/\.[a-zA-Z][a-zA-Z0-9_-]*/g)||[]).length,i=(t.match(/:[a-zA-Z-]+/g)||[]).length,n=(t.match(/\[[^\]]+\]/g)||[]).length,o=(t.match(/^[a-z]+|\s[a-z]+/gi)||[]).length,a=s+i+n;return{ids:e,classes:a,elements:o,score:`${e},${a},${o}`}}function It(t){const e=window.getComputedStyle(t);return{margin:{top:parseFloat(e.marginTop),right:parseFloat(e.marginRight),bottom:parseFloat(e.marginBottom),left:parseFloat(e.marginLeft)},border:{top:parseFloat(e.borderTopWidth),right:parseFloat(e.borderRightWidth),bottom:parseFloat(e.borderBottomWidth),left:parseFloat(e.borderLeftWidth)},padding:{top:parseFloat(e.paddingTop),right:parseFloat(e.paddingRight),bottom:parseFloat(e.paddingBottom),left:parseFloat(e.paddingLeft)}}}function Et(t){const e=window.getComputedStyle(t);return{fontSize:e.fontSize,fontWeight:e.fontWeight,fontFamily:e.fontFamily,lineHeight:e.lineHeight,letterSpacing:e.letterSpacing,color:e.color,textAlign:e.textAlign}}function kt(t){return{role:t.getAttribute("role")||"None",ariaLabel:t.getAttribute("aria-label")||"None",ariaLabelledBy:t.getAttribute("aria-labelledby")||"None",ariaDescribedBy:t.getAttribute("aria-describedby")||"None",ariaHidden:t.getAttribute("aria-hidden")||"false",tabIndex:t.getAttribute("tabindex")||"default",ariaLive:t.getAttribute("aria-live")||"None",ariaAtomic:t.getAttribute("aria-atomic")||"None"}}function At(t){const e=t.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);if(e){const s=parseInt(e[1]).toString(16).padStart(2,"0"),i=parseInt(e[2]).toString(16).padStart(2,"0"),n=parseInt(e[3]).toString(16).padStart(2,"0");return`#${s}${i}${n}`.toUpperCase()}return t}function Nt(t){const e=document.getElementById("ff-panel-header");if(!e)return;let s=0,i=0,n=0,o=0;e.style.cursor="grab",e.onmousedown=a;function a(c){if(c.target.closest("button"))return;c.preventDefault(),e.style.cursor="grabbing",n=c.clientX,o=c.clientY;const u=t.getBoundingClientRect();t.style.left=u.left+"px",t.style.top=u.top+"px",t.style.right="auto",t.style.bottom="auto",document.onmouseup=d,document.onmousemove=f}function f(c){c.preventDefault(),s=n-c.clientX,i=o-c.clientY,n=c.clientX,o=c.clientY;let u=t.offsetTop-i,g=t.offsetLeft-s;const l=window.innerWidth-t.offsetWidth,v=window.innerHeight-t.offsetHeight;g=Math.max(0,Math.min(g,l)),u=Math.max(0,Math.min(u,v)),t.style.top=u+"px",t.style.left=g+"px"}function d(){e.style.cursor="grab",document.onmouseup=null,document.onmousemove=null;try{localStorage.setItem("ff-panel-position",JSON.stringify({left:parseInt(t.style.left),top:parseInt(t.style.top)}))}catch{}}}function Mt(){try{document.querySelectorAll(".ff-collapsible-header").forEach(e=>{e.style.cursor="pointer",e.addEventListener("click",()=>{const s=e.closest(".ff-collapsible-section");if(!s)return;const i=s.getAttribute("data-section");if(!i)return;const n=s.querySelector(".ff-collapsible-content"),o=e.querySelector(".ff-collapse-icon");if(!n||!o)return;const a=s.classList.toggle("collapsed");a?(o.textContent="▶",n.style.maxHeight="0"):(o.textContent="▼",n.style.maxHeight=n.scrollHeight+"px");try{const f=JSON.parse(localStorage.getItem("ff-collapsed-sections")||"{}");f[i]=a,localStorage.setItem("ff-collapsed-sections",JSON.stringify(f))}catch{}})}),document.querySelectorAll(".ff-collapsible-section:not(.collapsed) .ff-collapsible-content").forEach(e=>{e.style.maxHeight=e.scrollHeight+"px"})}catch{}}function Bt(t){try{const s=document.getElementById("ff-collapse-all")?.querySelector(".ff-collapse-all-icon");if(!s)return;const i=t.classList.toggle("ff-panel-collapsed");i?s.textContent="▶":s.textContent="▼",localStorage.setItem("ff-panel-collapsed",String(i))}catch{}}function C(t){try{const e=document.querySelector(".ff-toast");e&&e.remove();const s=document.createElement("div");s.className="ff-toast",s.textContent=t,document.body.appendChild(s),setTimeout(()=>{s.remove()},2e3)}catch{}}function Pt(){try{chrome.runtime.onMessage.addListener((t,e,s)=>{try{t.action==="toggleInspect"&&(F(),s({isActive:m}))}catch{s({isActive:!1,error:!0})}return!0}),document.addEventListener("keydown",Ft)}catch{}}function Ft(t){try{if(t.ctrlKey&&t.shiftKey&&t.key==="I"){t.preventDefault(),F();return}if(t.key==="Escape"&&m){t.preventDefault(),b();const e=document.getElementById("ff-panel");e&&e.remove()}}catch{}}function F(){try{m?b():Rt()}catch{b()}}function Rt(){try{B(!0),rt(),Ht(),document.addEventListener("mousemove",R),document.addEventListener("click",H,!0),z()}catch{b()}}function b(){try{B(!1),p&&(p.remove(),P(null)),document.removeEventListener("mousemove",R),document.removeEventListener("click",H,!0);const t=document.getElementById("ff-panel");t&&t.remove(),z()}catch{}}function Ht(){try{const t=document.querySelector(".ff-highlight-box");t&&t.remove();const e=document.createElement("div");e.className="ff-highlight-box",e.id="ff-highlight-box",document.body.appendChild(e),P(e)}catch{}}const R=W(t=>{zt(t)},16);function zt(t){if(!(!m||!p))try{let e=document.elementFromPoint(t.clientX,t.clientY);if(e&&(e.id==="ff-highlight-box"||e.id==="ff-panel"||e.closest("#ff-panel")||e.closest(".ff-toast")||e.classList.contains("ff-highlight-box"))){p.style.display="none";return}if(!e||e===document.body||e===document.documentElement){p.style.display="none";return}const s=e.getBoundingClientRect();p.style.display="block",p.style.left=`${s.left+window.scrollX}px`,p.style.top=`${s.top+window.scrollY}px`,p.style.width=`${s.width}px`,p.style.height=`${s.height}px`}catch{}}function H(t){if(m)try{let e=document.elementFromPoint(t.clientX,t.clientY);if(e&&(e.id==="ff-highlight-box"||e.id==="ff-panel"||e.closest("#ff-panel")||e.closest(".ff-toast")||e.classList.contains("ff-highlight-box"))||!e||e===document.body||e===document.documentElement)return;t.preventDefault(),t.stopPropagation(),dt(e)}catch{}}function z(){try{chrome.runtime.sendMessage({action:"inspectorStateChanged",isActive:m}).catch(()=>{})}catch{}}(function(){try{O(),Pt()}catch{}})();
})()
